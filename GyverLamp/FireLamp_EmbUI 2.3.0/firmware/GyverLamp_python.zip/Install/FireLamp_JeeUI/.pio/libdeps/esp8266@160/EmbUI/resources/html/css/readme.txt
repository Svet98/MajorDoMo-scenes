pure-min.css - Responsive Rollup	https://unpkg.com/purecss@2.0.3/build/pure-min.css
side-menu - Left side menu              https://purecss.io/layouts/side-menu/#menu
