
#include "globals.h"

#define BAUD_RATE       115200  // serial debug port baud rate
